--
-- Author: Feng
-- Date: 2018-05-03 14:58:18
--
local sch  = require "framework.scheduler"

local ActivityLayer = class("ActivityLayer" ,function()
    return display.newLayer("ActivityLayer")
end)

function ActivityLayer:ctor()
	self:init()
end

function ActivityLayer:init()
	
      self.mPathArray = {
        "res/new_ui/test/1.png",
        "res/new_ui/test/2.png",
        "res/new_ui/test/3.png"
        }


	local csbNode = cc.CSLoader:createNode("new_ui/ActivityLayer.csb")
	csbNode:setAnchorPoint(0.5, 0.5)
	csbNode:setPosition(display.cx,display.cy)
	self:addChild(csbNode)
	self.rootNode = csbNode
--    self:addPathArray()
    self:initdata()
    self.ListView_Acctivity_Button = _G.seekNodeByName(self.rootNode,"ListView_Acctivity_Button")

    for i=1,#laixia.LocalPlayercfg.LunBoTitle do 
        local ActivityNode = require("lobby.layer.activity.ActivityNode").new()
        ActivityNode.tag = i
        ActivityNode:Update( self )
        ActivityNode:changeTitle(laixia.LocalPlayercfg.LunBoTitle[i])
        ActivityNode:setContentSize(cc.size(200,50))
	    self.ListView_Acctivity_Button:pushBackCustomItem(ActivityNode)
    end

    self.Button_Close = _G.seekNodeByName(self.rootNode,"Button_Close")
    self.Button_Close:addTouchEventListener(handler(self, self.onback))
	self.PageView_content = _G.seekNodeByName(self.rootNode,"PageView_content")
	self.Panel_content = _G.seekNodeByName(self.PageView_content,"Panel_content")
	self.Image_content = _G.seekNodeByName(self.Panel_content,"Image_content")
    self.PageView_content:addEventListener(handler(self, self.onPageViewEvent))
    self:updatePageView()

    print("================onenter===")


   self.mScheduler = sch.scheduleGlobal(function ()
           self.PageView_content:scrollToPage(2)
    end, 3)


end

function ActivityLayer:initdata()
    self.mPathArray = laixia.LocalPlayercfg.LaixiaLunBoPath[1]

end

function ActivityLayer:addPathArray()
   self.mPathArray = {}
   if #self.mPathArray > 0  then
       self.mPathArray = {}
   end
   if #laixia.LocalPlayercfg.LaixiaLunBoPath == 1 then
       for i=1,6 do
           for k,v in pairs(laixia.LocalPlayercfg.LaixiaLunBoPath) do
               table.insert(self.mPathArray,v)
           end   
       end
   elseif #laixia.LocalPlayercfg.LaixiaLunBoPath == 2 then
       for i=1,3 do
           for j,v in ipairs(laixia.LocalPlayercfg.LaixiaLunBoPath) do
               table.insert(self.mPathArray,v)
           end 
       end
   elseif #laixia.LocalPlayercfg.LaixiaLunBoPath == 3 then   
       for i=1,2 do
           for j,v in ipairs(laixia.LocalPlayercfg.LaixiaLunBoPath) do
               table.insert(self.mPathArray,v)
           end
       end
   elseif #laixia.LocalPlayercfg.LaixiaLunBoPath == 4 then
       for i=1,2 do
           for j,v in ipairs(laixia.LocalPlayercfg.LaixiaLunBoPath) do
               table.insert(self.mPathArray,v)
               if i == 2 and j == 2 then
                   break
               end
           end
       end      
   elseif #laixia.LocalPlayercfg.LaixiaLunBoPath == 5 then
       for i=1,2 do
           for j,v in ipairs(laixia.LocalPlayercfg.LaixiaLunBoPath) do
               table.insert(self.mPathArray,v)
               if i == 2 and j == 1 then
                   break
               end
           end
       end         
   elseif #laixia.LocalPlayercfg.LaixiaLunBoPath == 6 then
       for i,v in ipairs(laixia.LocalPlayercfg.LaixiaLunBoPath) do
           table.insert(self.mPathArray,v)
       end
   end
end

function ActivityLayer:changePage(tag)
--    self.mPathArray = {
--        "res/new_ui/test/1.png",
--        "res/new_ui/test/2.png",
--        "res/new_ui/test/3.png"
--        }
    --if eventType == ccui.TouchEventType.ended then
        --LaixiaLunBoPath
        print("changePage" .. tag)
        self.mPathArray = laixia.LocalPlayercfg.LaixiaLunBoPath[tag]
        self.PageView_content:scrollToPage(2)
    --end
end


--当前显示的页码(1 ~ pages)
local pageIdx = 1

function ActivityLayer:addPage(pIdx, iIdx, bClone)
 
    local newPage = nil
    if not bClone then
        newPage = self.PageView_content:getPage(0)
    else
        newPage = self.PageView_content:getPage(0):clone()
    end

    newPage:setTag(pIdx)

    local adImg = newPage:getChildByName("Image_content")

    adImg:loadTexture(self.mPathArray[pIdx])
    
    adImg:setSwallowTouches(false)
    adImg:setTouchEnabled(true)

    self.PageView_content:insertPage(newPage, iIdx)
 
end
 
--
function ActivityLayer:updatePageView()

    --删除原来的页面(第一页保留用于clone)
    for i = #self.PageView_content:getPages() - 1, 1, -1 do
        self.PageView_content:removePageAtIndex(i) 
    end
    --添加新的页面(每页显示6个)
    local pages = #self.mPathArray
 
    pageIdx = 1
 
    if 1 == pages then
        self:addPage(1, 0, false)
        self.PageView_content:scrollToPage(1)

    elseif 2 == pages then
        self:addPage(2, 0, false)
        self:addPage(1, 1, true)
        self:addPage(2, 2, true)
        self.PageView_content:scrollToPage(1)
    elseif pages >= 3 then
        self:addPage(pages, 0, false)
        self:addPage(1, 1, true)
        self:addPage(2, 2, true)
        self.PageView_content:scrollToPage(1)
    end
end


function ActivityLayer:onPageViewEvent(sender, eventType)
    if eventType == ccui.PageViewEventType.turning then
        local pages = #self.mPathArray
        local nextPageIdx = 0
        local curPageIndex = sender:getCurPageIndex()
        if pages >= 3 then
            if curPageIndex == 0 then
                pageIdx = pageIdx - 1
                if pageIdx <= 0 then pageIdx = pages end
 
                nextPageIdx = pageIdx - 1
                if nextPageIdx <= 0 then nextPageIdx = pages end
                sender:removePageAtIndex(2)
                self:addPage(nextPageIdx, 0, true)
                --PageView的当前页索引为0,在0的位置新插入页后原来的页面0变为1;
                --PageView自动显示为新插入的页面0,我们需要显示为页面1,所以强制滑动到1.
                sender:scrollToPage(1)
                --解决强制滑动到1后回弹效果
                sender:update(10)   
            elseif curPageIndex == 2 then
                pageIdx = pageIdx + 1
                if pageIdx > pages then pageIdx = 1 end
                nextPageIdx = pageIdx + 1
                if nextPageIdx > pages then    nextPageIdx = 1 end
                sender:removePageAtIndex(0)
                self:addPage(nextPageIdx, 2, true)
                sender:scrollToPage(1)
                -- sender:update(10)
            end
        elseif pages == 2 then
            if curPageIndex == 0 then
                nextPageIdx = 0
                if 1 == pageIdx then
                    pageIdx = 2
                    nextPageIdx = 1
                else
                    pageIdx = 1
                    nextPageIdx = 2
                end
                sender:removePageAtIndex(2)
                self:addPage(nextPageIdx, 0, true)
                --PageView的当前页索引为0,在0的位置新插入页后原来的页面0变为1;
                --PageView自动显示为新插入的页面0,我们需要显示为页面1,所以强制滑动到1.
                sender:scrollToPage(1)
                --解决强制滑动到1后回弹效果
                -- sender:update(10)   
 
            elseif curPageIndex == 2 then
                nextPageIdx = 0
                if 1 == pageIdx then
                    pageIdx = 2
                    nextPageIdx = 1
                else
                    pageIdx = 1
                    nextPageIdx = 2
                end
                sender:removePageAtIndex(0)
                self:addPage(nextPageIdx, 2, true)
            end
        end
    end
end


function ActivityLayer:onback(sender,eventType)
    if eventType == ccui.TouchEventType.ended then
        laixia.LocalPlayercfg.LunBoindex = 1
        self:removeAllChildren()
        sch.unscheduleGlobal(self.mScheduler)
    end
end


return ActivityLayer