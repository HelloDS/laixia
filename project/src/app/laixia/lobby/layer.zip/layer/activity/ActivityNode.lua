--
-- Author: Feng
-- Date: 2018-05-03 14:58:30
--
local ActivityNode = class("ActivityNode" ,function()
    return ccui.Layout:create() 
end)

function ActivityNode:ctor()
	self:init()
end

function ActivityNode:init()
    local pen = ccui.Layout:create() 
    pen:setContentSize(cc.size(100,50))
    self:addChild(pen)

	local csbNode = cc.CSLoader:createNode("new_ui/ActivityNode.csb")
	csbNode:setAnchorPoint(0, 0)
	csbNode:setPosition(94,28.5)
	pen:addChild(csbNode)
	self.rootNode = csbNode


    self.Button_activity = _G.seekNodeByName(self.rootNode,"Button_activity")
    self.Image_activity = _G.seekNodeByName(self.Button_activity,"Image_activity")

    self.Button_activity:addTouchEventListener( function ( sender,eventType)
	    if eventType == ccui.TouchEventType.ended then
		   --if self.tag == 1 then
                if self.tag == laixia.LocalPlayercfg.LunBoindex then
                    
                else
                    laixia.LocalPlayercfg.LunBoindex = self.tag
                    self.mlayer:changePage(self.tag)
                end
--           elseif self.tag == 2 then
--                if self.tag == laixia.LocalPlayercfg.LunBoindex then
--                    laixia.LocalPlayercfg.LunBoindex = 2
--                    self.mlayer:youxichangf1()
--                end
           --end
	    end 
    end)
end

function ActivityNode:changeTitle(data)
    local str = data
	self.Image_activity:loadTexture(str)
end

function ActivityNode:Update( layer )
    self.mlayer = layer
end

return ActivityNode