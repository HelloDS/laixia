--[[
    大厅主界面层

]]
local MainLayer = class("MainLayer")

--[[
    构造函数
]]
function MainLayer:ctor()
    
end

--[[
    初始化
]]
function MainLayer:init()

end

return MainLayer