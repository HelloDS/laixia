
--
-- Author: Feng
-- Date: 2018-05-03 12:53:49
--

local PersonCenterLayer = class("PersonCenterLayer" ,function()
    return display.newLayer("PersonCenterLayer")
end)

function PersonCenterLayer:ctor()
	print("bbbbbbbbbbbbbbbbbbbbbbbbbbb")
	self:init()
end

function PersonCenterLayer:init()
    print("cccccccc")
	local csbNode = cc.CSLoader:createNode("new_ui/PersonCenterLayer.csb")
	csbNode:setAnchorPoint(0.5, 0.5)
	csbNode:setPosition(display.cx,display.cy)
	self:addChild(csbNode)
	self.rootNode = csbNode

	self.Button_back = _G.seekNodeByName(self.rootNode,"Button_back")
    self.Button_back:addTouchEventListener(handler(self,self.onGotoBack))

    self.Image_icon = _G.seekNodeByName(self.rootNode,"Image_icon")
    self.Text_name = _G.seekNodeByName(self.rootNode,"Text_name")
    self.Text_ID = _G.seekNodeByName(self.rootNode,"Text_ID")
    self.Text_laidou = _G.seekNodeByName(self.rootNode,"Text_laidou")
    self.Text_phonebind = _G.seekNodeByName(self.rootNode,"Text_phonebind")
    self.Button_phonebind = _G.seekNodeByName(self.rootNode,"Button_phonebind")
    self.Button_phonebind:addTouchEventListener(handler(self,self.onGotoPhonebind))
    self.Button_wenhao = _G.seekNodeByName(self.rootNode,"Button_wenhao")
    self.Button_wenhao:addTouchEventListener(handler(self,self.onGotoWenhao))

    self.Text_yxc_total_number = _G.seekNodeByName(self.rootNode,"Text_yxc_total_number")
    self.Text_bsc_total_number = _G.seekNodeByName(self.rootNode,"Text_bsc_total_number")
    self.Text_yxc_win_number = _G.seekNodeByName(self.rootNode,"Text_yxc_win_number")
    self.Text_bsc_win_number = _G.seekNodeByName(self.rootNode,"Text_bsc_win_number")
    self.Text_yxc_win_rate = _G.seekNodeByName(self.rootNode,"Text_yxc_win_rate")
    self.Text_bsc_second_number = _G.seekNodeByName(self.rootNode,"Text_bsc_second_number")
    self:initData()
end

function PersonCenterLayer:initData()
	print("用数据初始化界面，和头像信息")
	print("用数据初始化界面，和头像信息"  .. "ffff")
	-- self.Image_icon:loadTexture()
	self.Text_name:setString(tostring(laixia.LocalPlayercfg.LaixiaPlayerNickname))
	self.Text_ID:setString("用户ID：" .. tostring(laixia.LocalPlayercfg.LaixiaPlayerID))
	self.Text_laidou:setString(tostring(laixia.LocalPlayercfg.LaixiaLdCoin))
	self.Text_phonebind:setString(tostring(laixia.LocalPlayercfg.PhoneNumber))
	self.Text_yxc_total_number:setString( "游戏场总副数" .. tostring(laixia.LocalPlayercfg.LaixiaPlayerVictoryTimes))
	--self.Text_bsc_total_number:setString( "比赛场总场数" .. tostring(laixia.LocalPlayercfg.LaixiaBisaiNum))
	self.Text_yxc_win_number:setString( "游戏场胜利总数" .. tostring(laixia.LocalPlayercfg.LaixiaPlayerMaxWintimes))
	--self.Text_bsc_win_number:setString( "比赛场冠军总场数" .. tostring(laixia.LocalPlayercfg.LaixiaBisaiWin))
	self.Text_yxc_win_rate:setString( "游戏场总胜率" .. tostring(laixia.LocalPlayercfg.LaixiaPlayerMaxWintimes/laixia.LocalPlayercfg.LaixiaPlayerVictoryTimes * 100) .. "%")
	-- self.Text_bsc_second_number:setString( "比赛场亚军总场数" .. tostring(laixia.LocalPlayercfg.LaixiaBisaiSecond))
end

function PersonCenterLayer:onGotoWenhao(sender,eventType)
	if eventType == ccui.TouchEventType.beganed then
		return true
	elseif eventType == ccui.TouchEventType.moveed then
	elseif eventType == ccui.TouchEventType.ended then
		--弹出问号窗口
		
	end
end

function PersonCenterLayer:onGotoPhonebind(sender,eventType)
	if eventType == ccui.TouchEventType.beganed then
		return true
	elseif eventType == ccui.TouchEventType.moveed then
	elseif eventType == ccui.TouchEventType.ended then
		local PhoneBindLayer = require("lobby.layer.personcenter.PhoneBindLayer").new()
		self:addChild(PhoneBindLayer)
	end
end

function PersonCenterLayer:onGotoBack(sender,eventType)
	if eventType == ccui.TouchEventType.beganed then
		return true
	elseif eventType == ccui.TouchEventType.moveed then
	elseif eventType == ccui.TouchEventType.ended then
		self:removeAllChildren()
	end
end

return PersonCenterLayer