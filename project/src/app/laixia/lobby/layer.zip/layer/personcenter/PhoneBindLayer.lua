--
-- Author: Feng
-- Date: 2018-05-03 17:18:47
--
local scheduler = require(cc.PACKAGE_NAME..".scheduler")

local PhoneBindLayer = class("PhoneBindLayer" ,function()
    return display.newLayer("PhoneBindLayer")
end)

function PhoneBindLayer:ctor()
	self:init()
end

function PhoneBindLayer:init()
	local csbNode = cc.CSLoader:createNode("new_ui/PhoneBindLayer.csb")
	csbNode:setAnchorPoint(0.5, 0.5)
	csbNode:setPosition(display.cx,display.cy)
	self:addChild(csbNode)
	self.rootNode = csbNode

	-- self. = _G:seekNodeByName(self.rootNote,"")
	-- self.Button_wenhao:addTouchEventListener(handler(self,self.onGotoBack))
	-- self. = _G:seekNodeByName(self.rootNote,"")
	-- self.Button_wenhao:addTouchEventListener(handler(self,self.sendBindPacket))
	-- self. = _G:seekNodeByName(self.rootNote,"")
	-- self.Button_wenhao:addTouchEventListener(handler(self,self.getCode))

	-- self. = _G:seekNodeByName(self.rootNote,"")
	-- self. = _G:seekNodeByName(self.rootNote,"")
end

function PhoneBindLayer:createEdit()
	self.PhoneNumber = ccui.EditBox:create(cc.size(420,50))--,"new_ui/PersonalCenterWindow/shurukuang1.png")
    self.PhoneNumber:setPosition(348,132)
    self.PhoneNumber:setPlaceHolder("请输入手机号码:")
    self.PhoneNumber:setFontSize(24)
    self.PhoneNumber:setFontColor(cc.c3b(69,63,56))
    self.PhoneNumber:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC)
    self.PhoneNumber:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE ) 
    local function editboxHandle( strEventName,sender ) 
        if strEventName == "began" then
        elseif strEventName == "ended" then
        elseif strEventName == "return" then
            sender:setText(sender:getText())
        elseif strEventName == "changed" then
            local test = 1
        end
    end
    self.PhoneNumber:registerScriptEditBoxHandler(function(eventname,sender) editboxHandle(eventname,sender) end) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
    :addChild(self.PhoneNumber)


    self.PhoneCode = ccui.EditBox:create(cc.size(200,50))--,"new_ui/PersonalCenterWindow/shurukuang2.png")
    self.PhoneCode:setPosition(239,60)
    self.PhoneCode:setFontSize(24)
    self.PhoneCode:setFontColor(cc.c3b(69,63,56))
    self.PhoneCode:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC)
    self.PhoneCode:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE ) 
    local function editboxHandle1( strEventName,sender ) 
        if strEventName == "began" then
        elseif strEventName == "ended" then
        elseif strEventName == "return" then 
            sender:setText(sender:getText())
        elseif strEventName == "changed" then
            local test = 1
        end
    end
    self.PhoneCode:registerScriptEditBoxHandler(function(eventname,sender) editboxHandle1(eventname,sender) end) --输入框的事件，主要有光标移进去，光标移出来，以及输入内容改变等
    :addChild(self.PhoneCode)
end

function PhoneBindLayer:onGotoBack(sender, eventType)
	if eventType == ccui.TouchEventType.ended then
		self:removeAllChildren()
	end
end

function PhoneBindLayer:getCode()
	if eventType == ccui.TouchEventType.ended then
		local time = 60
        scheduler:schedule(handler(self,self.onTick),60)
        --发送手机号 请求验证码
	end
end

function PhoneBindLayer:onTick(dt)
    -- if laixia.LocalPlayercfg.LaixiaMatchVerification then
    -- self.Btn_GetOver:setVisible(true)
    -- self.Btn_GetCode:setVisible(false)
    -- if (nowTime-(math.round(remainTime))>=1 ) then
    --     self.LabelSend = self:GetWidgetByName("Label_Time_Over")
    --     self.LabelSend:setVisible(true)
    --     self.LabelSend:setString(math.round(remainTime) .. "秒后重新获取")
    --     nowTime = remainTime
    -- end

    -- remainTime = remainTime - dt
    -- if (remainTime <= 0) then

    --     self.Btn_GetOver:setVisible(false)
    --     self.Btn_GetCode:setVisible(true)
    --     self.LabelSend:setVisible(false)

    --     laixia.LocalPlayercfg.LaixiaMatchVerification = false
    --     remainTime = PHONECODE_TIME -1
    --     nowTime = PHONECODE_TIME
    -- end
    -- end

    if time <= 0 then
    	scheduler.unscheduleGlobal(handler(self, self.onTick))
    else
    	time = time - 1
    	self.LabelSend:setString(time .. "秒后重新获取")
    end
end

function PhoneBindLayer:sendBindPacket(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
        local phonenumber  =self.PhoneNumber:getText()
        local code = self.PhoneCode:getText()
        if string.len(phonenumber) < 11  or tonumber(phonenumber) ==nil then           
            ObjectEventDispatch:pushEvent(_LAIXIA_EVENT_SHOW_MARKEDWORDS_WINDOW,"请输入11位手机号")
            return
        end
        if string.len(code)  < 6 then
            ObjectEventDispatch:pushEvent(_LAIXIA_EVENT_SHOW_MARKEDWORDS_WINDOW,"请输入6位验证码")
            return
        end
        --发送手机号 请求验证码
    end
end


return PhoneBindLayer