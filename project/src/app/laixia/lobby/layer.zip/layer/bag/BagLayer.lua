--
-- Author: Feng
-- Date: 2018-05-03 12:53:49
--
--[[
    大厅主界面层

]]
-- local JsonTxtData = lx.JsonTxtData
local BagLayer = class("BagLayer" ,function()
    return display.newLayer("BagLayer")
end)
--[[
    构造函数
]]
function BagLayer:ctor()
    self:init()
end

--[[
    初始化
]]
function BagLayer:init()
--初始化界面
    print("1111111")
    local csbNode = cc.CSLoader:createNode("new_ui/BagLayer.csb")
	csbNode:setAnchorPoint(0.5, 0.5)
	csbNode:setPosition(display.cx,display.cy)
	self:addChild(csbNode)
	self.rootNode = csbNode
    --返回按钮
    self.Button_back = _G.seekNodeByName(self.rootNode,"Button_back")
    self.Button_back:addTouchEventListener(handler(self,self.onBack))


    self.Panel_button = _G.seekNodeByName(self.rootNode,"Panel_button")
    --左边四个按钮
    self.Button_all = _G.seekNodeByName(self.Panel_button,"Button_all")
    --self.Button_all:setVisible(false)
    self.Button_ticket = _G.seekNodeByName(self.Panel_button,"Button_ticket")
    --self.Button_ticket:setVisible(false)
    self.Button_prop = _G.seekNodeByName(self.Panel_button,"Button_prop")
    --self.Button_prop:setVisible(false)
    self.Button_prize = _G.seekNodeByName(self.Panel_button,"Button_prize")
    --self.Button_prize:setVisible(false)

    self.Button_all_select = _G.seekNodeByName(self.Panel_button,"Button_all_select")
    self.Button_all_select:setVisible(false)
    self.Button_ticket_select = _G.seekNodeByName(self.Panel_button,"Button_ticket_select")
    self.Button_ticket_select:setVisible(false)
    self.Button_prop_select = _G.seekNodeByName(self.Panel_button,"Button_prop_select")
    self.Button_prop_select:setVisible(false)
    self.Button_prize_select = _G.seekNodeByName(self.Panel_button,"Button_prize_select")
    self.Button_prize_select:setVisible(false)

    --self.Button_all:addTouchEventListener(handler(self,self.onCleanup))
    self.Button_all_select:addTouchEventListener(handler(self,self.showAllIteam))
    --self.Button_ticket:addTouchEventListener(handler(self,self.onCleanup))
    self.Button_ticket_select:addTouchEventListener(handler(self,self.showMenpiao))
    --self.Button_prop:addTouchEventListener(handler(self,self.onCleanup))
    self.Button_prop_select:addTouchEventListener(handler(self,self.showTools))
    --self.Button_prize:addTouchEventListener(handler(self,self.onCleanup))
    self.Button_prize_select:addTouchEventListener(handler(self,self.showExchange))

    

    
    --加载的控件
    self.Panel_cell = _G.seekNodeByName(self.rootNode,"Panel_cell")
    self.mLibaoCell = self.Panel_cell
    for i=1,3 do 
        _G.seekNodeByName(self.mLibaoCell,"Panel_item" .. i):setVisible(false)
    end
    --cell的三个物品
    -- self.Button_item_1 = _G.seekNodeByName(self.Panel_cell,"Button_item_1")
    -- self.Button_item_1:addTouchEventListener(handler(self, self.onBack))
    -- self.Button_item_2 = _G.seekNodeByName(self.Panel_cell,"Button_item_2")
    -- self.Button_item_2:addTouchEventListener(handler(self, self.onBack))
    -- self.Button_item_3 = _G.seekNodeByName(self.Panel_cell,"Button_item_3")
    -- self.Button_item_3:addTouchEventListener(handler(self, self.onBack))
    


    --四个list容器
    self.Panel_listvecter = _G.seekNodeByName(self.rootNode,"Panel_listvecter")
    self.ListView_all = _G.seekNodeByName(self.Panel_listvecter,"ListView_all")
    self.ListView_ticket = _G.seekNodeByName(self.Panel_listvecter,"ListView_ticket")
    self.ListView_prop = _G.seekNodeByName(self.Panel_listvecter,"ListView_prop")
    self.ListView_prize = _G.seekNodeByName(self.Panel_listvecter,"ListView_prize")

    self.mListViewLibao = self.ListView_all
    self.Mybag_duijiangList = self.ListView_prize
    self.ListView_ticket = self.ListView_ticket
    self.Mybag_daojuList = self.ListView_prop


    self.ButtonArray ={}
    table.insert(self.ButtonArray,self.Button_all)
    table.insert(self.ButtonArray,self.Button_all_select)
    table.insert(self.ButtonArray,self.Button_ticket)
    table.insert(self.ButtonArray,self.Button_ticket_select)
    table.insert(self.ButtonArray,self.Button_prop)
    table.insert(self.ButtonArray,self.Button_prop_select)
    table.insert(self.ButtonArray,self.Button_prize)
    table.insert(self.ButtonArray,self.Button_prize_select)
    
    --更新listview
    self:updateWindow()
end

--显示唯一的空间，当前显示为单数
function BagLayer:onShowOnly(index,nodeArray)
    print("3333333")
    if index > #nodeArray then
        return
    else
        for i,v in ipairs(nodeArray) do
            local n = i%2
            if (i == index  ) then
                v:show()
            elseif(i %2 == 0) then
                v:show()
            else
                v:hide()
            end

        end
        nodeArray[index+1]:hide()
    end
end

--显示唯一的前景按钮
function BagLayer:showOnlyButton(index)
    self:onShowOnly(index,self.ButtonArray)    
end

function BagLayer:updateWindow()
    -- if self.mIsShow then
        --ObjectEventDispatch:pushEvent(_LAIXIA_EVENT_SHOW_BAGRED_WINDOW)

        laixia.LocalPlayercfg.LaixiaPropsData = {}
        laixia.LocalPlayercfg.LaixiaPropsData[1] = {}
        laixia.LocalPlayercfg.LaixiaPropsData[1].ItemCount = 7
        laixia.LocalPlayercfg.LaixiaPropsData[1].ItemID = 1501
        laixia.LocalPlayercfg.LaixiaPropsData[1].itm_id = "1501"
        laixia.LocalPlayercfg.LaixiaPropsData[1].id = 3
        laixia.LocalPlayercfg.LaixiaPropsData[1].EffTime = 0
        laixia.LocalPlayercfg.LaixiaPropsData[1].ItemName = "小白"
        --数据保存在laixia.LocalPlayercfg.LaixiaPropsData 变量中
        local propsItems = laixia.LocalPlayercfg.LaixiaPropsData 


        -- 遍历是否有任务红包（如果有的话就把它放到第一个位置）
        for k,v in pairs(propsItems) do
            local temp = {}
            if v.ItemID == 13002 and k ~= 1 then
                temp = propsItems[1]
                propsItems[1] = propsItems[k]
                propsItems[k] = temp
            end
        end
        print("2222222")
        --四个UINode数组
        self.mUINodeArray = {};
        self.daojuUINodeArray = {};
        self.menpiaoUINodeArray = {}
        self.duijiangUINodeArray = {};


        --四个UIitemMsg数组
        self.mUIItemMsgArray = { }
        --道具 门票 兑奖
        self.mMenpiaoArray = {}
        self.mDuijiangArray = {}
        self.mDaojuArray = {}

        -- 标记一下当前的道具 (按钮注释了 这个也没什么用了)       
        self:showOnlyButton(1)

        --暂时注释掉
        -- local itemMsg = JsonTxtData:queryTable("items")
        --1501    0   1元红包    3       0                           1       0                       
        self.itemMsg = {}
        self.itemMsg.PlatformID = 0
        self.itemMsg.ItemName = "1元红包"
        self.itemMsg.ItemType = 3
        self.itemMsg.UmitPrice = 1
        self.itemMsg.PileNum = 1
        self.itemMsg.ImagePath =  "res/new_ui/bag/libao.png"
        self.itemMsg.ItemDesc = "使用后，将通过微信公众号自动为您发放1元红包，请您注意查收"



        for i,v in ipairs(propsItems) do
            --暂时注释掉
            --local itemData =itemMsg:query("ItemID",v.ItemID)
            local itemData = self.itemMsg
            if itemData then
                if itemData.ItemType == 2 then
                    table.insert(self.mMenpiaoArray,v)
                --elseif itemData.ItemType == 7 or itemData.ItemType==0 or itemData.ItemType==2 then
                elseif itemData.ItemType == 3 then
                    table.insert(self.mDuijiangArray,v)
                else
                    --table.insert(self.mDaojuArray,v)
                end
                table.insert(self.mUIItemMsgArray,v)
            end
        end


        self.mListViewLibao:removeAllItems()
        self.Mybag_duijiangList:removeAllItems()
        self.ListView_ticket:removeAllItems()
        self.Mybag_daojuList:removeAllItems()

        self:addItems();
        if (self.mUINodeArray[1] ~= nil) then
            self.Index = 1
--            self:hideTips()
        else
--            self:showTips()
        end
        self:showAllIteam()
    -- end
end

--显示所有物品
function BagLayer:showAllIteam(sender, eventType)
    -- if eventType == ccui.TouchEventType.ended then
        self:showOnlyButton(1)
        self.mListViewLibao:setVisible(true)
        self.Mybag_daojuList:setVisible(false)
        self.Mybag_menpiaoList:setVisible(false)
        self.Mybag_duijiangList:setVisible(false)
    -- end
end

--显示道具
function BagLayer:showTools(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
        self:showOnlyButton(3)
        self.mListViewLibao:setVisible(false)
        self.Mybag_daojuList:setVisible(true)
        self.Mybag_menpiaoList:setVisible(false)
        self.Mybag_duijiangList:setVisible(false)
    end
end

--显示门票
function BagLayer:showMenpiao(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
        self:showOnlyButton(5)
        self.mListViewLibao:setVisible(false)
        self.Mybag_daojuList:setVisible(false)
        self.Mybag_menpiaoList:setVisible(true)
        self.Mybag_duijiangList:setVisible(false)
    end
end

--显示兑换
function BagLayer:showExchange(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
        self:showOnlyButton(7)
        self.mListViewLibao:setVisible(false)
        self.Mybag_daojuList:setVisible(false)
        self.Mybag_menpiaoList:setVisible(false)
        self.Mybag_duijiangList:setVisible(true)
    end
end

--添加item数据和节点到表中
function BagLayer:addItems()
    --定义一个局部变量 保存Item数

    local itemNumber
    --for listViewIndex=1,4 do
    for listViewIndex=1,4 do-----现在只走listViewIndex==1（就是显示全部Item）
        local dataArray = {}
        local dataArrays = {}

        
        if listViewIndex==1 then
            dataArrays = self.mUIItemMsgArray
        elseif listViewIndex==2 then
            dataArrays = self.mDaojuArray
        elseif listViewIndex == 3 then
            dataArrays = self.mMenpiaoArray
        elseif listViewIndex==4 then
            dataArrays = self.mDuijiangArray
        end

        -- dataArrays[1] = {ItemID = 1501,ItemCount = 5,EffTime = 0}
        -- dataArrays[2] = {ItemID = 1001,ItemCount = 6,EffTime = 0}        
        for i=1,#dataArrays do
        local itemid = dataArrays[i].ItemID
        --暂时注释掉
           -- local itemMsg = JsonTxtData:queryTable("items"):query("ItemID",itemid); 
           local itemMsg = self.itemMsg

            if itemMsg.isPile == 0 then
                for j=1,dataArrays[i].ItemCount do
                    dataArray[#dataArray+1] = clone(dataArrays[i])
                    dataArray[#dataArray].ItemCount = 1
                end
            else
                if itemMsg.PileNum >= dataArrays[i].ItemCount then
                     dataArray[#dataArray+1] = clone(dataArrays[i])
                else 
                    local counts = dataArrays[i].ItemCount
                    local num1 =  math.floor(dataArrays[i].ItemCount / itemMsg.PileNum)
                    local num2 =  counts % itemMsg.PileNum
                    for j=1,num1 do
                         dataArray[#dataArray+1] = clone(dataArrays[i])
                        dataArray[#dataArray].ItemCount = itemMsg.PileNum
                        --  dataArrays[i].ItemCount = itemMsg.PileNum
                        -- table.insert(dataArray,dataArrays[i])
                    end

                    local num2 =  counts % itemMsg.PileNum
                    if (num2 ~= 0) then
                        num1 = num1+1
                        dataArray[#dataArray+1] = clone(dataArrays[i])
                        dataArray[#dataArray].ItemCount = num2
                    end   
                end
            end
        end
     

        self.dataArrayss = dataArray

        if listViewIndex == 1 then
            itemNumber = #dataArray
        elseif listViewIndex == 2 then
            itemNumber = #dataArray
        elseif listViewIndex == 3 then
            itemNumber = #dataArray
        elseif listViewIndex == 4 then
            itemNumber = #dataArray
        end

--------获取有几行控件 最后一行控件有几个item
        --totalNumber 用来记录有几行 向下取整(返回小于参数x的最大整数)
        local totalNumber =  math.floor(itemNumber / 5)
        --numberMod   用来最后一行的Item的个数
        local numberMod =  itemNumber% 5

        local addModelNumber = totalNumber
        --如果最后一行的Item的个数~=0 那么行+1(因为上面是向下取整的)
        if (numberMod ~= 0) then 
            addModelNumber = totalNumber + 1
        end
--------

--------控件

        --遍历行
        for i=1,addModelNumber do 
            local model = self.mLibaoCell:clone()
            if listViewIndex==1 then
                self.mListViewLibao:pushBackCustomItem(model);
            elseif listViewIndex==2 then
                self.Mybag_daojuList:pushBackCustomItem(model);
            elseif listViewIndex == 3 then
                self.Mybag_menpiaoList:pushBackCustomItem(model);
            elseif listViewIndex==4 then
                self.Mybag_duijiangList:pushBackCustomItem(model);
            end

            local size = model:getContentSize()
            local length =  size.width/5
            local pointstart = size.width/8

            for j=1,3 do 
                local idx = j
                --index = 当前是所有控件中的第几个 注意:i从1，j从0开始
                local index = 3*(i-1) + j+1
                if (dataArray[index] ~=nil and dataArray[index].ItemCount >= 0 )then
                    --暂时注释掉
                   -- local itemMsg = JsonTxtData:queryTable("items"):query("ItemID",dataArray[index].ItemID);
                   local itemMsg = self.itemMsg 
                    --取出克隆的基础容器(行)上的item(列)
                    local btnModel = _G.seekNodeByName(self.Panel_cell,"Panel_item" .. idx)
                    self.model_ = btnModel
                    local index = 3*(i-1) + j+1
                    if (dataArray[index] ~=nil and dataArray[index].ItemCount >= 0 )then
                        btnModel:show()
                        btnModel:setTag(index)
                        if listViewIndex == 1 then
                            self.mUINodeArray[#self.mUINodeArray + 1] = btnModel
                        elseif listViewIndex == 2 then
                            self.daojuUINodeArray[#self.daojuUINodeArray + 1] = btnModel
                        elseif listViewIndex == 3 then
                            self.menpiaoUINodeArray[#self.menpiaoUINodeArray + 1] = btnModel
                        elseif listViewIndex == 4 then
                            self.duijiangUINodeArray[#self.duijiangUINodeArray + 1] = btnModel
                        end    
                        --重新保存取出克隆的基础容器(行)上的item(列)           
                        local model_sender = _G.seekNodeByName(self.Panel_cell,"Panel_item" .. idx)
                        --取出item的id保存
                        model_sender.ItemID = dataArray[index].ItemID
                        --取出itemObjectID 保存
                        model_sender.ItemObjectID = dataArray[index].ItemObjectID
                        --添加item的按钮监听
                        --self:AddWidgetEventListenerFunction("Mybag_SingleLibao_0"..idx, handler(self, self.onClickToShow),model); --绑定使用函数
                        -- self.isLight = false
                        model_sender:addTouchEventListener(handler(self, self.onClickToShow))
                        --self:AddWidgetEventListenerFunction("Mybag_SingleLibao_0" .. idx,handler(self, self.onClickToShow),model)
                        -- self:GetWidgetByName("Mybag_guangxiao", self.model_):setVisible(false)
                        -- local gx = _G.seekNodeByName(model_sender,"Mybag_guangxiao")
                        -- gx:setVisible(false)
                    end
                end
            end
        end

        -- 填充
        for i = 1, itemNumber do
            --self:AddWidgetEventListenerFunction("Mybag_SingleLibao_0" .. i,handler(self, self.onClickToShow),model)
            self:addItem(i, dataArray[i],listViewIndex);
        end
    end
end 

function BagLayer:onClickToShow(sender,eventType)
    if eventType == ccui.TouchEventType.ended then
        local BagItemLayer = require("lobby.layer.bag.BagItemLayer")
        self:addChild(BagItemLayer)
        local yz = BagItemLayer:getPositionY()
        local xz = BagItemLayer:getPositionX()
        BagItemLayer:setPositionY(100)
        local move = cc.MoveTo:create(2,cc.p(xz,yz))
        BagItemLayer:runAction(move)
    end
end

--添加Item到界面上 并设置Item上的节点
function BagLayer:addItem(index, item,tabIndex)
    local dataArray = {}
    if tabIndex==1 then
        dataArray = self.dataArrayss
    elseif tabIndex==2 then
        dataArray = self.dataArrayss
    elseif tabIndex == 3 then
        dataArray = self.dataArrayss
    elseif tabIndex==4 then
        dataArray = self.dataArrayss
    end
    --暂时注释掉
    --local itemData =JsonTxtData:queryTable("items"):query("ItemID",item.ItemID);
    local itemData = self.itemMsg
    if (itemData ~= nil) then
        -- ObjectEventDispatch:pushEvent(_LAIXIA_EVENT_SHOW_BAGTIPS_WINDOW)
        if tabIndex == 1 then
            self.control = self.mUINodeArray[index];
        elseif tabIndex == 2 then
            self.control = self.daojuUINodeArray[index]
        elseif tabIndex == 3 then
            self.control = self.menpiaoUINodeArray[index]
        elseif tabIndex == 4 then
            self.control = self.duijiangUINodeArray[index]
        end
       -- self.control:setTag(index);

        local name = _G.seekNodeByName(self.control,"Text_des")
        name:setString(itemData.ItemName)



        --图片图标
        local icon = _G.seekNodeByName(self.control,"Image_prize")
        icon:setVisible(false)
        local baoming_Array = string.split(itemData.ImagePath ,'/')
        icon:removeAllChildren()
        if #baoming_Array >1 then
            local sprite = display.newSprite(itemData.ImagePath)
            sprite:setScale(0.4)  
            sprite:setAnchorPoint(cc.p(0.5,0.5))
            sprite:setPosition(cc.p(0,0))
            sprite:addTo(icon)
        else
           
            
            --ImagePath字段 道具大icon############
            icon:loadTexture(itemData.ImagePath, 1)
            icon:setScale(0.5)            
        end
        icon:setVisible(true)

        local Button_use = _G.seekNodeByName(self.control,"Button_use")
        --需要的参数在这带过去
        --Button_use.itemID
        Button_use:addTouchEventListener(handler(self, self.onUse))


        --物品数量
        --local BT_use = self:GetWidgetByName("Mybag_Libao_Use");
        --self.Image_27 = self:GetWidgetByName("Image_27")
        --self.Image_27:setVisible(false)
        --暂时注释掉
        local text_time = _G.seekNodeByName(self.control,"Text_time")
        text_time:setVisible(true)

        --1002只显示数量  五个类型中哪几种只不显示use？？？？？？？？
        -- if dataArray[index].ItemID == 1002 then
        --    BT_use:setVisible(false)
        -- end 

        --如果effTime不是永久有效
        if dataArray[index].EffTime > 0 and itemData.isPile==0 then
            --self:GetWidgetByName("Image_27", self.control):setVisible(true)
            --text_time:setVisible(true)
            local diff = dataArray[index].EffTime/1000 - os.time()
            local time1 = math.floor(diff/60/60/24)
            print("time1")
            --local day = dataArray[index].EffTime   
            -- self.Image_27:setVisible(true)
            text_time:setVisible(true)
           text_time:setString(time1.."天")
            local Text_number = _G.seekNodeByName(self.control,"Text_number")
            Text_number:setVisible(false)
            --self:GetWidgetByName("Mybag_Libao_Num", self.control):setVisible(false)  --显示道具数量
        else
            --self:GetWidgetByName("Image_27", self.control):setVisible(false)
            text_time:setVisible(false)
             local Text_number = _G.seekNodeByName(self.control,"Text_number")
            Text_number:setString("4")--暂时注释掉--dataArray[index].ItemCount)
        end

        --如果可赠送
--        if itemData.isGiver ~= nil and 1 == itemData.isGiver then
--           local bt_Present =  self:GetWidgetByName("Mybag_Libao_Present", self.control) 
--           bt_Present:setVisible(true)
--           bt_Present.ItemID = self.mUIItemMsgArray[index].ItemID
--           bt_Present.ItemObjectID = self.mUIItemMsgArray[index].ItemObjectID
--           bt_Present.ItemNum = self.mUIItemMsgArray[index].ItemCount
--           self:GetWidgetByName("Label_Present",bt_Present):setString("赠送")
--           bt_Present:addTouchEventListener(handler(self, self.onPresent))
--        else
--           self:GetWidgetByName("Mybag_Libao_Present", self.control) :setVisible(false)
--        end
    end
end 

-- function BagLayer:onUse(sender,eventType)
--     if eventType == ccui.TouchEventType.ended then
--         --发送使用红包请求
--     end
-- end



function BagLayer:onBack(sender,eventType)
    if eventType == ccui.TouchEventType.ended then
        self:removeAllChildren()
    end
    
end
return BagLayer