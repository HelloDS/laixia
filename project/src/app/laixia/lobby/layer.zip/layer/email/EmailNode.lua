--
-- Author: Feng
-- Date: 2018-05-03 14:58:54
--

local EmailNode = class("EmailNode" ,function()
    return cc.Node:create() 
end)
--[[
    构造函数
]]
function EmailNode:ctor()
    self:init()
end

--[[
    初始化
]]
function EmailNode:init()
--初始化界面
    local csbNode = cc.CSLoader:createNode("new_ui/EmailNode.csb")
	csbNode:setAnchorPoint(0, 0)
	csbNode:setPosition(0,0)--display.cx,display.cy)
	self:addChild(csbNode)
	self.rootNode = csbNode
    self.Image_photo = _G.seekNodeByName(self.rootNode,"Image_photo")
    self.Text_content = _G.seekNodeByName(self.rootNode,"Text_content")
    self.Text_time:enableOutline(cc.c4b(153, 108, 67, 255), 2)
    self.Text_time = _G.seekNodeByName(self.rootNode,"Text_time")
    self.Text_time:enableOutline(cc.c4b(153, 108, 67, 255), 2)
end
function EmailNode:initPhoto(data)
	self.Image_photo:loadTexture("new_ui/email/tubiao.png")
end
function EmailNode:initTime(str)
	self.Text_time:setString(str)
end
function EmailNode:initContent(str)
	self.Text_content:setString(str)
end
function EmailNode:render(data)

end
return EmailNode