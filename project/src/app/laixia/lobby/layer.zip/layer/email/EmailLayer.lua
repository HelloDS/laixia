local userDefault = cc.UserDefault:getInstance()
local schedu = require("framework.scheduler")

local EmailLayer = class("EmailLayer" ,function()
    return display.newLayer("EmailLayer")
end)
--[[
    构造函数
]]
function EmailLayer:ctor(...)
    self:init(...)
end

function EmailLayer:init(...)
--初始化界面
    local csbNode = cc.CSLoader:createNode("new_ui/EmailLayer.csb")
	csbNode:setAnchorPoint(0.5, 0.5)
	csbNode:setPosition(display.cx,display.cy)
	self:addChild(csbNode)
	self.rootNode = csbNode
	self.Panel_root = _G.seekNodeByName(self.rootNode, "Panel_root")
    self.Button_cleanup = _G.seekNodeByName(self.rootNode,"Button_cleanup")
    self.Button_cleanup:addTouchEventListener(handler(self,self.onCleanup))
    self.Button_back = _G.seekNodeByName(self.rootNode,"Button_back")
    self.Button_back:addTouchEventListener(handler(self, self.onBack))
    self.ListView_email = _G.seekNodeByName(self.rootNode,"ScrollView_email")
    --self.Panel_cell = _G.seekNodeByName(self.ScrollView_email,"Panel_cell")

 --    local sizeScroll = self.ScrollView_email:getContentSize()
	-- local posotionScroll = cc.p(self.ScrollView_email:getPositionX(),self.ScrollView_email:getPositionY())
	-- self.ScrollView_email:removeFromParent()
 --    self.TableView_email = cc.TableView:create(sizeScroll)
 	self:updateWindow(...)

    self.mScheduler = schedu.scheduleUpdateGlobal(handler(self,self.onTick))
end

function EmailLayer:updateWindow(msg)
    --if self.mIsShow then
    self.letterArray = {}
    self.mIndex = 0
    if msg then
        self.letterArray = msg
    end

    --PrintTable(msg)
    print("jjjjjjjjjjjjjjjjjj" .. #self.letterArray)
    self:getLetterArray()
    -- self.ListView_email = _G.seekNodeByName(self.rootNode,"ScrollView_email")
    -- self.ListView_email:removeAllItems()
    self:saveLetter()
    --self:onTick()
    --end
end

function EmailLayer:saveLetter()
    for i, v in ipairs(self.letterArray) do
        if i <= 30 then
            userDefault:setStringForKey(laixia.LocalPlayercfg.LaixiaPlayerID .. "sendTime" .. i,v.sendTime)
            userDefault:setStringForKey(laixia.LocalPlayercfg.LaixiaPlayerID .. "conText" .. i,v.Context)
        end
    end
    userDefault:setIntegerForKey(laixia.LocalPlayercfg.LaixiaPlayerID .. "number", #self.letterArray)
end

function EmailLayer:onTick()
    print("vvvvvvvvvvvvvv")
    if not self.mIsShow then
        return
    end
    if self.mIndex == #self.letterArray then
        --此处存放为空的时候界面显示的逻辑
        return
    end
    -- local old = self.mIndex + 1

    -- if self.mIndex+5 > #self.letterArray then
    --     self.mIndex = #self.letterArray
    -- else
    --     self.mIndex =self.mIndex +5
    -- end
    self:addLetterLiset(old, self.mIndex)
end

function EmailLayer:addLetterLiset(begin,overChoose)
	print("mmmmmmmmmmmmmm")
    for i = begin, overChoose do
        item = require "laixia.layer.lobby.email.EmailNode".new()
        local time = self.letterArray[idx].sendTime
        item:initTime(os.date("%X",time))
        --暂时注释掉
        --local context  = self.letterArray[i].Context:gsub("金币",laixia.utilscfg.CoinType());
        item:initContent(context)
        cell:addChild(item)

        self.listview_Email:pushBackCustomItem(item)
    end
end

function EmailLayer:getLetterArray()
    local number = userDefault:getIntegerForKey(laixia.LocalPlayercfg.LaixiaPlayerID .. "number")
    print("kkkkkkkkkkkk" .. number)
    if number ~= nil and number > 0 then
        for i = 1, number do
            if laixia.LocalPlayercfg.LaixiaHeartBeatTime == 0 then
                local heartTime = userDefault:getStringForKey("heartTime")
                if heartTime~=nil then
                    laixia.LocalPlayercfg.LaixiaHeartBeatTime = tonumber(heartTime)
                end
            end
            ----暂时加上  到时后台直接发时间戳就行
            local time_1 = userDefault:getStringForKey(laixia.LocalPlayercfg.LaixiaPlayerID .. "sendTime" .. i)
            local time_qf = self:split(time_1," ")
            local time_qian = time_qf[1]
            local time_hou = time_qf[2]
            local time_qian_qf = self:split(time_qian,"-")
            local nian = time_qian_qf[1]
            local yue = time_qian_qf[2] 
            local ri = time_qian_qf[3]
            local time_hou_qf = self:split(time_hou,":")
            local shi = time_hou_qf[1]
            local fen = time_hou_qf[2]
            local miao = time_hou_qf[3]
            local tiem_qian = self:split(time_qf[1])

            --2018-05-04 12:16:14
            local time = os.time({year =nian, month = yue, day =ri, hour =shi, min =fen, sec = miao})
            -----------
            --暂时注释掉
            --local cha = (laixia.LocalPlayercfg.LaixiaHeartBeatTime/1000) - tonumber(os.time(userDefault:getStringForKey(laixia.LocalPlayercfg.LaixiaPlayerID .. "sendTime" .. i)))
            local cha = (laixia.LocalPlayercfg.LaixiaHeartBeatTime/1000) - time

            --暂时注释掉
            --if cha < (laixia.config.LAIXIA_SHOW_STATINMASSAGE*24*3600) then    --7天等于518400
            if cha < (518400) then  
                local letter = {}
                letter["sendTime"] = userDefault:getStringForKey(laixia.LocalPlayercfg.LaixiaPlayerID .. "sendTime" .. i)
                letter["Context"] = userDefault:getStringForKey(laixia.LocalPlayercfg.LaixiaPlayerID .. "conText" .. i)
                --暂时注释掉
                --letter["Context"] = letter["Context"]:gsub("金币",laixia.utilscfg.CoinType());
                table.insert(self.letterArray, letter)
            end
        end
    end
end

function EmailLayer:split(input, delimiter)
    input = tostring(input)
    delimiter = tostring(delimiter)
    if (delimiter=='') then return false end
    local pos,arr = 0, {}
    for st,sp in function() return string.find(input, delimiter, pos, true) end do
        table.insert(arr, string.sub(input, pos, st - 1))
        pos = sp + 1
    end
    table.insert(arr, string.sub(input, pos))
    return arr
end

function EmailLayer:onClearup(msg)
    userDefault:setIntegerForKey(laixia.LocalPlayercfg.LaixiaPlayerID .. "number", 0)
    self.listview_Email:removeAllItems()
end

function EmailLayer:onBack()
    self:removeAllChildren()
    sched.unscheduleGlobal(self.mScheduler)
    self:onDestroy()
end

function EmailLayer:onDestroy()
    self.letterArray = {}
    self.mIndex = 0
end



return EmailLayer